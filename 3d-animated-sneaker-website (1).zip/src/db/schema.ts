import {
  index,
  integer,
  jsonb,
  pgTable,
  timestamp,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

export type OrderLine = {
  productId: string;
  name: string;
  size: string;
  quantity: number;
  unitPrice: number;
};

export const orderRequests = pgTable(
  "order_requests",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    customerName: varchar("customer_name", { length: 100 }).notNull(),
    phone: varchar("phone", { length: 32 }).notNull(),
    items: jsonb("items").$type<OrderLine[]>().notNull(),
    totalNpr: integer("total_npr").notNull(),
    status: varchar("status", { length: 20 }).notNull().default("pending"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("order_requests_created_at_idx").on(table.createdAt)],
);
