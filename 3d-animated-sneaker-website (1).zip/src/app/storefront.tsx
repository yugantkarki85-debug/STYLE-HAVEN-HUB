"use client";

/* eslint-disable @next/next/no-img-element */
import { useEffect, useMemo, useRef, useState } from "react";
import type { FormEvent } from "react";

type Brand = "Nike" | "Adidas" | "New Balance";
type Filter = "All pairs" | Brand | "Under NPR 20K";
type SortOrder = "Featured" | "Price: low to high" | "Price: high to low";
type Product = {
  id: string;
  brand: Brand;
  name: string;
  price: number;
  image: string;
  alt: string;
  color: string;
  badge?: string;
  note: string;
};
type CartItem = { productId: string; size: string; quantity: number };
type IconName = "arrow" | "bag" | "search" | "heart" | "close" | "pin" | "phone" | "plus" | "minus" | "spark" | "menu" | "check" | "instagram";

const products: Product[] = [
  {
    id: "jordan-1-high",
    brand: "Nike",
    name: "Air Jordan 1 Retro High OG",
    price: 28900,
    image: "https://images.pexels.com/photos/10195371/pexels-photo-10195371.jpeg?auto=compress&cs=tinysrgb&w=950&h=950&fit=crop",
    alt: "Black and yellow high-top basketball sneaker in a close-up studio photograph",
    color: "#e9e4d9",
    badge: "MOST WANTED",
    note: "The one that started the conversation.",
  },
  {
    id: "air-force-1",
    brand: "Nike",
    name: "Air Force 1 '07",
    price: 18500,
    image: "https://images.pexels.com/photos/4277508/pexels-photo-4277508.jpeg?auto=compress&cs=tinysrgb&w=950&h=950&fit=crop",
    alt: "White low-top sneaker with red accents photographed against a brick wall",
    color: "#eee9e4",
    badge: "THE EVERYDAY",
    note: "An all-day classic. Zero extra effort.",
  },
  {
    id: "dunk-low",
    brand: "Nike",
    name: "Dunk Low Retro",
    price: 19800,
    image: "https://images.pexels.com/photos/17825341/pexels-photo-17825341.jpeg?auto=compress&cs=tinysrgb&w=950&h=950&fit=crop",
    alt: "Sporty low-top sneaker in pale green with black detailing",
    color: "#e2e9dc",
    badge: "JUST LANDED",
    note: "Soft green. Serious rotation potential.",
  },
  {
    id: "nb-9060",
    brand: "New Balance",
    name: "9060 Silver Metallic",
    price: 22900,
    image: "https://images.pexels.com/photos/27988923/pexels-photo-27988923.jpeg?auto=compress&cs=tinysrgb&w=950&h=950&fit=crop",
    alt: "Silver-toned contemporary running sneakers on a light grey set",
    color: "#e2e3e2",
    badge: "FUTURE CLASSIC",
    note: "A little retro. A lot of presence.",
  },
  {
    id: "samba-og",
    brand: "Adidas",
    name: "Samba OG",
    price: 15900,
    image: "https://images.pexels.com/photos/6150128/pexels-photo-6150128.jpeg?auto=compress&cs=tinysrgb&w=950&h=950&fit=crop",
    alt: "Black and white low-profile sneakers outdoors on rocky ground",
    color: "#e7e2da",
    badge: "CITY FAVOURITE",
    note: "Old-school lines. New-school attitude.",
  },
  {
    id: "jordan-low",
    brand: "Nike",
    name: "Air Jordan 1 Low",
    price: 22400,
    image: "https://images.pexels.com/photos/16923479/pexels-photo-16923479.jpeg?auto=compress&cs=tinysrgb&w=950&h=950&fit=crop",
    alt: "Black and cream low-cut basketball sneakers worn as streetwear",
    color: "#e7e3dc",
    badge: "LOW KEY, NEVER",
    note: "Made for the long way home.",
  },
  {
    id: "air-max-dn",
    brand: "Nike",
    name: "Air Max DN",
    price: 19900,
    image: "https://images.pexels.com/photos/18946632/pexels-photo-18946632.jpeg?auto=compress&cs=tinysrgb&w=950&h=950&fit=crop",
    alt: "Vibrant technical running sneaker with vivid colours and sculpted sole",
    color: "#e9e2dd",
    badge: "MOVE DIFFERENT",
    note: "Big energy from the ground up.",
  },
  {
    id: "street-runner",
    brand: "Adidas",
    name: "Campus Street Runner",
    price: 16900,
    image: "https://images.pexels.com/photos/16350687/pexels-photo-16350687.jpeg?auto=compress&cs=tinysrgb&w=950&h=950&fit=crop",
    alt: "Curated streetwear sneakers and shoeboxes arranged for a shop-floor editorial",
    color: "#e7e1d8",
    badge: "OFF-DUTY",
    note: "Your favourite plans are the unplanned ones.",
  },
];

const filters: Filter[] = ["All pairs", "Nike", "Adidas", "New Balance", "Under NPR 20K"];
const sizes = ["39", "40", "41", "42", "43", "44", "45"];
const formatPrice = (price: number) => `NPR ${price.toLocaleString("en-IN")}`;

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const shared = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.7,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true as const,
  };

  switch (name) {
    case "arrow":
      return <svg {...shared}><path d="M4.75 12h14.5M13 5.75 19.25 12 13 18.25" /></svg>;
    case "bag":
      return <svg {...shared}><path d="M5 8h14l1 12H4L5 8Z" /><path d="M9 9V6a3 3 0 0 1 6 0v3" /></svg>;
    case "search":
      return <svg {...shared}><circle cx="10.8" cy="10.8" r="6.7" /><path d="m16 16 4 4" /></svg>;
    case "heart":
      return <svg {...shared}><path d="M20.5 8.7c0 4.2-8.5 10-8.5 10S3.5 12.9 3.5 8.7a4.2 4.2 0 0 1 7.7-2.3l.8 1 .8-1a4.2 4.2 0 0 1 7.7 2.3Z" /></svg>;
    case "close":
      return <svg {...shared}><path d="m6 6 12 12M18 6 6 18" /></svg>;
    case "pin":
      return <svg {...shared}><path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0Z" /><circle cx="12" cy="10" r="2.2" /></svg>;
    case "phone":
      return <svg {...shared}><path d="M7 3.5 4.9 4.7a2 2 0 0 0-1 2.1c1.3 6.4 6.3 11.4 12.7 12.7a2 2 0 0 0 2.1-1L20 16.4l-4.1-2-1.5 2a14 14 0 0 1-6.8-6.8l2-1.5L7 3.5Z" /></svg>;
    case "plus":
      return <svg {...shared}><path d="M12 5v14M5 12h14" /></svg>;
    case "minus":
      return <svg {...shared}><path d="M5 12h14" /></svg>;
    case "spark":
      return <svg {...shared}><path d="m12 2 1.5 6.2L20 10l-6.5 1.8L12 18l-1.5-6.2L4 10l6.5-1.8L12 2Z" /><path d="m19 16 .7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7L19 16Z" /></svg>;
    case "menu":
      return <svg {...shared}><path d="M4 7h16M4 12h16M4 17h16" /></svg>;
    case "check":
      return <svg {...shared}><path d="m5 12.5 4.5 4.5L19 7" /></svg>;
    case "instagram":
      return <svg {...shared}><rect x="3.5" y="3.5" width="17" height="17" rx="5" /><circle cx="12" cy="12" r="4" /><path d="M17.7 6.4h.01" /></svg>;
  }
}

export default function Storefront() {
  const [filter, setFilter] = useState<Filter>("All pairs");
  const [sortOrder, setSortOrder] = useState<SortOrder>("Featured");
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartReady, setCartReady] = useState(false);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [wishlistReady, setWishlistReady] = useState(false);
  const [bagOpen, setBagOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedSize, setSelectedSize] = useState("42");
  const [checkoutName, setCheckoutName] = useState("");
  const [checkoutPhone, setCheckoutPhone] = useState("");
  const [checkoutPending, setCheckoutPending] = useState(false);
  const [checkoutError, setCheckoutError] = useState("");
  const [orderNumber, setOrderNumber] = useState("");
  const [toast, setToast] = useState("");
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    try {
      const savedCart = window.localStorage.getItem("shh-cart-v1");
      const savedWishlist = window.localStorage.getItem("shh-wishlist-v1");
      if (savedCart) {
        const parsed = JSON.parse(savedCart) as CartItem[];
        if (Array.isArray(parsed)) setCart(parsed);
      }
      if (savedWishlist) {
        const parsed = JSON.parse(savedWishlist) as string[];
        if (Array.isArray(parsed)) setWishlist(parsed);
      }
    } catch {
      window.localStorage.removeItem("shh-cart-v1");
      window.localStorage.removeItem("shh-wishlist-v1");
    }
    setCartReady(true);
    setWishlistReady(true);
  }, []);

  useEffect(() => {
    if (cartReady) window.localStorage.setItem("shh-cart-v1", JSON.stringify(cart));
  }, [cart, cartReady]);

  useEffect(() => {
    if (wishlistReady) window.localStorage.setItem("shh-wishlist-v1", JSON.stringify(wishlist));
  }, [wishlist, wishlistReady]);

  useEffect(() => {
    if (searchOpen) searchRef.current?.focus();
  }, [searchOpen]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2500);
    return () => window.clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setBagOpen(false);
        setSelectedProduct(null);
        setSearchOpen(false);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  const visibleProducts = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();
    const matching = products.filter((product) => {
      const matchesFilter = filter === "All pairs"
        || (filter === "Under NPR 20K" ? product.price < 20000 : product.brand === filter);
      const matchesQuery = !normalizedQuery
        || `${product.name} ${product.brand} ${product.note}`.toLowerCase().includes(normalizedQuery);
      return matchesFilter && matchesQuery;
    });
    if (sortOrder === "Price: low to high") matching.sort((a, b) => a.price - b.price);
    if (sortOrder === "Price: high to low") matching.sort((a, b) => b.price - a.price);
    return matching;
  }, [filter, query, sortOrder]);

  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
  const cartTotal = cart.reduce((total, item) => {
    const product = products.find((entry) => entry.id === item.productId);
    return total + (product?.price ?? 0) * item.quantity;
  }, 0);

  function openProduct(product: Product) {
    setSelectedSize("42");
    setSelectedProduct(product);
  }

  function addToBag(product: Product, size: string) {
    setCart((current) => {
      const match = current.find((item) => item.productId === product.id && item.size === size);
      if (match) {
        return current.map((item) => item === match ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...current, { productId: product.id, size, quantity: 1 }];
    });
    setSelectedProduct(null);
    setOrderNumber("");
    setCheckoutError("");
    setToast(`${product.name} added to your bag`);
  }

  function changeQuantity(productId: string, size: string, amount: number) {
    setCart((current) => current
      .map((item) => item.productId === productId && item.size === size
        ? { ...item, quantity: item.quantity + amount }
        : item)
      .filter((item) => item.quantity > 0));
  }

  async function placeOrder(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setCheckoutError("");
    setCheckoutPending(true);
    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: checkoutName,
          phone: checkoutPhone,
          items: cart.map(({ productId, size, quantity }) => ({ productId, size, quantity })),
        }),
      });
      const result = (await response.json()) as { orderNumber?: string; error?: string };
      if (!response.ok || !result.orderNumber) {
        throw new Error(result.error ?? "We couldn't save your request. Please try WhatsApp instead.");
      }
      setOrderNumber(result.orderNumber);
      setCart([]);
      setToast(`Order SHH-${result.orderNumber} saved — we’ll be in touch`);
    } catch (error) {
      setCheckoutError(error instanceof Error ? error.message : "Something went wrong. Please try again.");
    } finally {
      setCheckoutPending(false);
    }
  }

  function toggleWishlist(product: Product) {
    const isSaved = wishlist.includes(product.id);
    setWishlist((current) => isSaved
      ? current.filter((id) => id !== product.id)
      : [...current, product.id]);
    setToast(isSaved ? "Removed from your saved pairs" : "Pair saved for later");
  }

  const whatsappMessage = encodeURIComponent(
    `Namaste! I'd like to order from Style Haven Hub:\n${cart.map((item) => {
      const product = products.find((entry) => entry.id === item.productId);
      return `• ${product?.name ?? "Sneaker"} — EU ${item.size} × ${item.quantity}`;
    }).join("\n")}\n\nTotal: ${formatPrice(cartTotal)}`,
  );

  return (
    <div className="storefront">
      <div className="announcement" aria-label="Store announcement">
        <div className="announcement-track">
          {Array.from({ length: 4 }, (_, index) => (
            <span className="announcement-message" key={index} aria-hidden={index > 0}>
              <Icon name="spark" size={15} /> YOUR CITY. YOUR PACE. YOUR PAIR.
              <i /> KATHMANDU, NEPAL <i /> STEP INTO SOMETHING BETTER <b>✳</b>
            </span>
          ))}
        </div>
      </div>

      <header className="site-header">
        <div className="nav-wrap">
          <a className="wordmark" href="#home" aria-label="Style Haven Hub home">
            <span className="wordmark-emblem">sh<span>.</span></span>
            <span className="wordmark-copy">STYLE HAVEN<span>HUB / KATHMANDU</span></span>
          </a>
          <nav className="desktop-nav" aria-label="Main navigation">
            <a href="#collection">The collection</a>
            <a href="#story">Our point of view</a>
            <a href="#visit">Find us</a>
          </nav>
          <div className="nav-actions">
            <a className="city-label" href="https://www.google.com/maps/search/?api=1&query=P858%2BP4+Kathmandu+Bagmati+Province" target="_blank" rel="noreferrer">
              <span className="status-dot" /> KATHMANDU, NP
            </a>
            <button className={`icon-button search-trigger${searchOpen ? " is-active" : ""}`} type="button" aria-label={searchOpen ? "Close search" : "Search sneakers"} onClick={() => setSearchOpen((open) => !open)}>
              {searchOpen ? <Icon name="close" /> : <Icon name="search" />}
            </button>
            <button className="bag-trigger" type="button" onClick={() => setBagOpen(true)} aria-label={`Open shopping bag${cartCount > 0 ? `, ${cartCount} items` : ""}`}>
              <Icon name="bag" size={19} /><span className="bag-word">BAG</span><span className="bag-count">{cartCount}</span>
            </button>
          </div>
        </div>
        {searchOpen && (
          <form className="search-panel" role="search" onSubmit={(event) => { event.preventDefault(); document.getElementById("collection")?.scrollIntoView({ behavior: "smooth" }); }}>
            <Icon name="search" size={20} />
            <input ref={searchRef} value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Try ‘Dunk’, ‘Nike’ or your next favourite…" aria-label="Search the sneaker collection" />
            {query && <button type="button" className="search-clear" onClick={() => setQuery("")}>CLEAR</button>}
            <span className="search-shortcut">ESC TO CLOSE</span>
          </form>
        )}
      </header>

      <main>
        <section className="hero" id="home" aria-labelledby="hero-heading">
          <img className="hero-art" src="/images/hero-sneaker.jpg" alt="Sculptural white sneaker with electric lime details, photographed in a dark studio" fetchPriority="high" />
          <div className="hero-shade" />
          <div className="hero-grid-lines" aria-hidden="true" />
          <div className="hero-main">
            <div className="hero-copy">
              <div className="eyebrow hero-eyebrow"><span className="eyebrow-dot" /> THE NEXT STEP STARTS HERE</div>
              <h1 id="hero-heading">Own your<br /><em>own</em> <span className="hero-outline">pace.</span></h1>
              <p className="hero-description">Good sneakers change the way you move. Better ones change the whole mood.</p>
              <a className="primary-cta" href="#collection">Find your pair <Icon name="arrow" size={18} /></a>
              <div className="hero-footnote"><span>CURATED FOR THE STREETS OF KTM</span><span className="footnote-rule" /><span>EST. WITH INTENTION</span></div>
            </div>
          </div>
          <div className="hero-top-note"><span>01 / 03</span><span>THE DAILY ROTATION</span></div>
          <div className="hero-sticker" aria-hidden="true"><span>WALK</span><b>✳</b><span>YOUR</span><span>WAY</span></div>
          <div className="hero-bottom"><span>STYLE HAS A HOME.</span><span className="hero-bottom-center"><i /> KATHMANDU, NEPAL</span><span>27° 43′ 00.0″ N</span></div>
        </section>

        <div className="ticker-bar" aria-hidden="true">
          <div className="ticker-content">FRESH PAIRS. FRESH PERSPECTIVE. <span>✳</span> FRESH PAIRS. FRESH PERSPECTIVE. <span>✳</span> FRESH PAIRS. FRESH PERSPECTIVE. <span>✳</span> FRESH PAIRS. FRESH PERSPECTIVE. <span>✳</span></div>
        </div>

        <section className="collection-section section-wrap" id="collection" aria-labelledby="collection-title">
          <div className="section-heading-row">
            <div>
              <div className="eyebrow section-eyebrow"><span className="section-number">01</span> THE ROTATION</div>
              <h2 className="section-title" id="collection-title">Pairs with <span>presence.</span></h2>
              <p className="section-subtitle">The ones you wear on repeat — and people notice.</p>
            </div>
            <span className="collection-aside">HANDPICKED IN KATHMANDU <span>↗</span></span>
          </div>

          <div className="catalog-toolbar">
            <div className="filter-list" role="group" aria-label="Filter sneakers by brand">
              {filters.map((item) => (
                <button className={`filter-chip${filter === item ? " is-selected" : ""}`} type="button" key={item} onClick={() => setFilter(item)} aria-pressed={filter === item}>{item}</button>
              ))}
            </div>
            <label className="sort-control"><span>SORT</span><select value={sortOrder} onChange={(event) => setSortOrder(event.target.value as SortOrder)} aria-label="Sort sneakers">
              <option>Featured</option><option>Price: low to high</option><option>Price: high to low</option>
            </select></label>
          </div>

          {visibleProducts.length > 0 ? (
            <div className="product-grid" aria-live="polite">
              {visibleProducts.map((product, index) => {
                const saved = wishlist.includes(product.id);
                return (
                  <article className="product-card" key={product.id} style={{ animationDelay: `${Math.min(index, 6) * 70}ms` }}>
                    <div className="product-visual" style={{ backgroundColor: product.color }}>
                      {product.badge && <span className="product-badge">{product.badge}</span>}
                      <button className={`wishlist-button${saved ? " is-saved" : ""}`} type="button" onClick={() => toggleWishlist(product)} aria-label={saved ? `Remove ${product.name} from saved pairs` : `Save ${product.name}`} aria-pressed={saved}><Icon name="heart" size={18} /></button>
                      <button className="product-image-button" type="button" onClick={() => openProduct(product)} aria-label={`View ${product.name}`}>
                        <img className="product-image" src={product.image} alt={product.alt} loading="lazy" />
                      </button>
                      <button className="quick-add-button" type="button" onClick={() => openProduct(product)} aria-label={`Choose a size for ${product.name}`}><Icon name="plus" size={19} /></button>
                      <span className="product-index">SHH / 0{index + 1}</span>
                    </div>
                    <div className="product-info">
                      <div className="product-brandline"><span>{product.brand.toUpperCase()}</span><span className="product-colors"><i /><i /><i /></span></div>
                      <button className="product-name-button" type="button" onClick={() => openProduct(product)}>{product.name}<span className="product-open-arrow">↗</span></button>
                      <div className="product-lower"><span>{formatPrice(product.price)}</span><span>EU 39–45</span></div>
                    </div>
                  </article>
                );
              })}
            </div>
          ) : (
            <div className="empty-results"><span className="empty-icon"><Icon name="search" size={24} /></span><h3>No pairs on this route.</h3><p>Try another search, or take a look at all the good ones.</p><button className="text-link" type="button" onClick={() => { setQuery(""); setFilter("All pairs"); }}>Show every pair <Icon name="arrow" size={17} /></button></div>
          )}
          <div className="collection-foot"><span>GOOD TASTE HAS NO SHORTCUTS.</span><span>{visibleProducts.length} PAIRS TO EXPLORE</span></div>
        </section>

        <section className="point-of-view section-wrap" id="story" aria-labelledby="story-title">
          <div className="story-photo-wrap">
            <img src="https://images.pexels.com/photos/16923479/pexels-photo-16923479.jpeg?auto=compress&cs=tinysrgb&w=1050&h=1180&fit=crop" alt="Streetwear sneakers ready for a walk through the city" loading="lazy" />
            <div className="story-photo-shade" />
            <span className="story-photo-caption">A GOOD PAIR GETS YOU OUT THERE.</span>
            <div className="story-side-stamp">KTM<br />27°N</div>
            <div className="story-counter"><span>01</span><i /> STYLE IS A JOURNEY</div>
          </div>
          <div className="story-copy">
            <div className="eyebrow section-eyebrow"><span className="section-number">02</span> OUR POINT OF VIEW</div>
            <h2 id="story-title">The city<br />is <em>your</em><br />runway.</h2>
            <p>From the first coffee to the last turn home — the right pair just feels like you. We bring together the sneakers worth making room for, and let your own style do the talking.</p>
            <a className="story-link" href="#visit">A little more about us <span><Icon name="arrow" size={18} /></span></a>
            <div className="story-signoff"><span>GOOD THINGS START FROM THE GROUND UP.</span><span>SHH—001</span></div>
          </div>
        </section>

        <section className="visit-section section-wrap" id="visit" aria-labelledby="visit-title">
          <div className="visit-kicker"><span className="eyebrow section-eyebrow"><span className="section-number">03</span> YOUR LOCAL SNEAKER STOP</span><span className="visit-little-star">✳</span></div>
          <div className="visit-layout">
            <div className="visit-main">
              <div className="visit-copy">
                <h2 id="visit-title">Meet us<br /><em>in Kathmandu.</em></h2>
                <p>See a pair you like? Come say namaste, give them a closer look, or message us and we’ll help you find your size.</p>
                <div className="visit-actions">
                  <a className="primary-cta visit-cta" href="https://www.google.com/maps/search/?api=1&query=P858%2BP4+Kathmandu+Bagmati+Province" target="_blank" rel="noreferrer">Get directions <Icon name="arrow" size={18} /></a>
                  <a className="visit-phone" href="tel:+9779801245421"><Icon name="phone" size={17} /> 980-1245421</a>
                </div>
              </div>
              <div className="map-card" aria-label="Location: Kathmandu, Bagmati Province">
                <div className="map-grid" />
                <div className="map-road map-road-one" /><div className="map-road map-road-two" /><div className="map-road map-road-three" />
                <span className="map-cross map-cross-a">✳</span><span className="map-cross map-cross-b">✳</span>
                <div className="map-pin"><Icon name="pin" size={25} /><span>YOU ARE HERE</span></div>
                <span className="map-label map-label-one">KATHMANDU</span><span className="map-label map-label-two">BAGMATI</span>
                <a className="map-open-link" href="https://www.google.com/maps/search/?api=1&query=P858%2BP4+Kathmandu+Bagmati+Province" target="_blank" rel="noreferrer" aria-label="Open Style Haven Hub location in Google Maps"><Icon name="arrow" size={18} /></a>
              </div>
            </div>
            <div className="visit-address"><span className="address-label"><Icon name="pin" size={16} /> DROP BY THE NEIGHBOURHOOD</span><span>Kathmandu, Bagmati Province 44600</span><span className="address-code">P858+P4 KATHMANDU, NEPAL</span></div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="footer-main">
          <a className="footer-wordmark" href="#home"><span className="wordmark-emblem">sh<span>.</span></span><span>STYLE HAVEN HUB</span></a>
          <p>Good sneakers.<br />Good days ahead.</p>
          <a className="footer-social" href="https://www.instagram.com/" target="_blank" rel="noreferrer" aria-label="Instagram"><Icon name="instagram" size={19} /></a>
        </div>
        <div className="footer-bottom"><span>© {new Date().getFullYear()} STYLE HAVEN HUB — KATHMANDU, NEPAL</span><a href="#home">BACK TO THE TOP <span>↑</span></a><span>WALK YOUR OWN WAY.</span></div>
      </footer>

      {bagOpen && (
        <div className="drawer-overlay" onMouseDown={(event) => { if (event.target === event.currentTarget) setBagOpen(false); }}>
          <aside className="bag-drawer" role="dialog" aria-modal="true" aria-labelledby="bag-title">
            <div className="drawer-header"><div><span className="drawer-eyebrow">THE GOOD STUFF</span><h2 id="bag-title">Your bag <span>({cartCount})</span></h2></div><button className="icon-button" type="button" onClick={() => setBagOpen(false)} aria-label="Close bag"><Icon name="close" /></button></div>
            {orderNumber ? (
              <div className="order-success">
                <span className="order-success-icon"><Icon name="check" size={26} /></span>
                <span className="drawer-eyebrow">ORDER REQUEST SAVED</span>
                <h3>Nice one.<br />We’ve got your order.</h3>
                <p>Your request number is <strong>SHH-{orderNumber}</strong>. We’ll get in touch at the number you left to confirm availability and next steps.</p>
                <div className="order-details-note"><Icon name="phone" size={15} /> Need us sooner? <a href="tel:+9779801245421">Call 980-1245421</a></div>
                <button className="primary-cta" type="button" onClick={() => { setBagOpen(false); setOrderNumber(""); }}>Keep browsing <Icon name="arrow" size={17} /></button>
              </div>
            ) : cart.length > 0 ? (
              <>
                <div className="cart-items">{cart.map((item) => {
                  const product = products.find((entry) => entry.id === item.productId);
                  if (!product) return null;
                  return <div className="cart-item" key={`${item.productId}-${item.size}`}>
                    <div className="cart-item-image" style={{ backgroundColor: product.color }}><img src={product.image} alt="" /></div>
                    <div className="cart-item-info"><span className="cart-item-brand">{product.brand.toUpperCase()}</span><h3>{product.name}</h3><span className="cart-item-size">SIZE EU {item.size} · {formatPrice(product.price)}</span><div className="quantity-controls"><button type="button" onClick={() => changeQuantity(item.productId, item.size, -1)} aria-label={`Remove one ${product.name}`}><Icon name="minus" size={14} /></button><span>{item.quantity}</span><button type="button" onClick={() => changeQuantity(item.productId, item.size, 1)} aria-label={`Add one ${product.name}`}><Icon name="plus" size={14} /></button></div></div>
                    <span className="cart-line-price">{formatPrice(product.price * item.quantity)}</span>
                  </div>;
                })}</div>
                <div className="bag-summary">
                  <div className="summary-row"><span>SUBTOTAL</span><span>{formatPrice(cartTotal)}</span></div>
                  <p>No payment right now. We’ll confirm the details with you.</p>
                  <form className="checkout-form" onSubmit={placeOrder}>
                    <div className="checkout-form-heading"><span>MAKE IT YOURS</span><span>NO PAYMENT YET</span></div>
                    <label>YOUR NAME<input name="customerName" type="text" autoComplete="name" required minLength={2} maxLength={100} placeholder="What should we call you?" value={checkoutName} onChange={(event) => { setCheckoutName(event.target.value); setCheckoutError(""); }} /></label>
                    <label>PHONE / WHATSAPP<input name="phone" type="tel" autoComplete="tel" required maxLength={32} placeholder="Number we can reach you on" value={checkoutPhone} onChange={(event) => { setCheckoutPhone(event.target.value); setCheckoutError(""); }} /></label>
                    {checkoutError && <p className="checkout-error" role="alert">{checkoutError}</p>}
                    <button className="whatsapp-order checkout-submit" type="submit" disabled={checkoutPending}>{checkoutPending ? "SENDING YOUR REQUEST…" : "Place order request"}<Icon name="arrow" size={18} /></button>
                  </form>
                  <a className="whatsapp-fallback" href={`https://wa.me/9779801245421?text=${whatsappMessage}`} target="_blank" rel="noreferrer"><span>Prefer WhatsApp?</span><b>Send your bag <Icon name="arrow" size={15} /></b></a>
                  <span className="bag-secure-note"><Icon name="check" size={14} /> YOUR ORDER REQUEST IS SAVED PRIVATELY</span>
                </div>
              </>
            ) : (
              <div className="empty-bag"><span className="empty-bag-mark"><Icon name="bag" size={32} /></span><h3>Nothing in here. Yet.</h3><p>Your next favourite pair is just a scroll away.</p><button className="primary-cta" type="button" onClick={() => { setBagOpen(false); document.getElementById("collection")?.scrollIntoView({ behavior: "smooth" }); }}>Meet the collection <Icon name="arrow" size={17} /></button></div>
            )}
          </aside>
        </div>
      )}

      {selectedProduct && (
        <div className="modal-overlay" onMouseDown={(event) => { if (event.target === event.currentTarget) setSelectedProduct(null); }}>
          <section className="product-modal" role="dialog" aria-modal="true" aria-labelledby="modal-product-name">
            <button className="modal-close icon-button" type="button" onClick={() => setSelectedProduct(null)} aria-label="Close product details"><Icon name="close" /></button>
            <div className="modal-photo" style={{ backgroundColor: selectedProduct.color }}><img src={selectedProduct.image} alt={selectedProduct.alt} /></div>
            <div className="modal-details"><span className="drawer-eyebrow">{selectedProduct.brand.toUpperCase()} · STYLE HAVEN EDIT</span><h2 id="modal-product-name">{selectedProduct.name}</h2><span className="modal-price">{formatPrice(selectedProduct.price)}</span><p>{selectedProduct.note} Choose your size and we’ll take it from here.</p><div className="size-label"><span>SELECT SIZE</span><a href="tel:+9779801245421">Need a hand?</a></div><div className="size-grid" role="group" aria-label="Select a European shoe size">{sizes.map((size) => <button key={size} type="button" className={selectedSize === size ? "is-selected" : ""} aria-pressed={selectedSize === size} onClick={() => setSelectedSize(size)}>{size}</button>)}</div><button className="whatsapp-order modal-add" type="button" onClick={() => addToBag(selectedProduct, selectedSize)}>Add to bag <span>EU {selectedSize}</span><Icon name="arrow" size={18} /></button><span className="modal-help"><Icon name="phone" size={14} /> Questions? Call us on 980-1245421</span></div>
          </section>
        </div>
      )}

      {toast && <div className="toast-message" role="status"><span><Icon name="check" size={16} /></span>{toast}<button type="button" onClick={() => setBagOpen(true)}>VIEW BAG</button></div>}
    </div>
  );
}
