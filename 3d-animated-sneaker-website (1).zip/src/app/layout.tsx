import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Style Haven Hub — Sneakers for Your Own Pace",
  description:
    "Find your next favourite pair at Style Haven Hub, Kathmandu. Explore a handpicked sneaker edit featuring Nike, Adidas, and New Balance.",
  openGraph: {
    title: "Style Haven Hub — Sneakers for Your Own Pace",
    description:
      "Good sneakers change the way you move. Find your pair in Kathmandu.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
