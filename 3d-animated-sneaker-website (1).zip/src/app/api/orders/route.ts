import { NextResponse } from "next/server";
import { db } from "@/db";
import { orderRequests, type OrderLine } from "@/db/schema";

const catalog: Record<string, { name: string; price: number }> = {
  "jordan-1-high": { name: "Air Jordan 1 Retro High OG", price: 28900 },
  "air-force-1": { name: "Air Force 1 '07", price: 18500 },
  "dunk-low": { name: "Dunk Low Retro", price: 19800 },
  "nb-9060": { name: "9060 Silver Metallic", price: 22900 },
  "samba-og": { name: "Samba OG", price: 15900 },
  "jordan-low": { name: "Air Jordan 1 Low", price: 22400 },
  "air-max-dn": { name: "Air Max DN", price: 19900 },
  "street-runner": { name: "Campus Street Runner", price: 16900 },
};

const availableSizes = new Set(["39", "40", "41", "42", "43", "44", "45"]);

export async function POST(request: Request) {
  let input: Record<string, unknown>;
  try {
    const body: unknown = await request.json();
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      return NextResponse.json({ error: "Please check your order details." }, { status: 400 });
    }
    input = body as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Please send a valid order." }, { status: 400 });
  }

  const customerName = typeof input.customerName === "string" ? input.customerName.trim() : "";
  const phone = typeof input.phone === "string" ? input.phone.trim() : "";
  const phoneDigits = phone.replace(/\D/g, "");

  if (customerName.length < 2 || customerName.length > 100) {
    return NextResponse.json({ error: "Please enter your name (2–100 characters)." }, { status: 400 });
  }
  if (phone.length > 32 || phoneDigits.length < 7 || phoneDigits.length > 15) {
    return NextResponse.json({ error: "Please enter a valid phone number so we can reach you." }, { status: 400 });
  }
  if (!Array.isArray(input.items) || input.items.length < 1 || input.items.length > 24) {
    return NextResponse.json({ error: "Your bag must contain at least one pair." }, { status: 400 });
  }

  const items: OrderLine[] = [];
  for (const value of input.items) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      return NextResponse.json({ error: "One of the items in your bag is invalid." }, { status: 400 });
    }
    const line = value as Record<string, unknown>;
    const productId = typeof line.productId === "string" ? line.productId : "";
    const size = typeof line.size === "string" ? line.size : "";
    const quantity = line.quantity;
    const product = catalog[productId];

    if (!product || !availableSizes.has(size) || typeof quantity !== "number" || !Number.isInteger(quantity) || quantity < 1 || quantity > 9) {
      return NextResponse.json({ error: "Please check the sizes and quantities in your bag." }, { status: 400 });
    }

    items.push({ productId, name: product.name, size, quantity, unitPrice: product.price });
  }

  const totalNpr = items.reduce((total, item) => total + item.unitPrice * item.quantity, 0);
  try {
    const [order] = await db
      .insert(orderRequests)
      .values({ customerName, phone, items, totalNpr })
      .returning({ id: orderRequests.id });

    return NextResponse.json(
      { orderId: order.id, orderNumber: order.id.slice(0, 8).toUpperCase() },
      { status: 201 },
    );
  } catch (error) {
    console.error("Unable to save Style Haven Hub order request", error);
    return NextResponse.json(
      { error: "We couldn't save your request right now. Please try WhatsApp instead." },
      { status: 500 },
    );
  }
}
